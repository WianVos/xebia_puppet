CREATE OR REPLACE FUNCTION pgpool_regclass(cstring)
RETURNS oid
AS '$libdir/pgpool-regclass', 'pgpool_regclass'
LANGUAGE C STRICT;
